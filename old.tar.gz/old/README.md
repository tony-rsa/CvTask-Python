# CvTask-Python
CvTask allows its users to very easily perform computer vision tasks and  operations on images. 
